from __future__ import annotations

import re
import unicodedata

_TOKEN_RE = re.compile(r"[0-9A-Za-z가-힣_./:@+-]+")
_HANGUL_RE = re.compile(r"^[가-힣]+$")


def normalize_text(text: str) -> str:
    value = unicodedata.normalize("NFKC", text)
    value = value.replace("\x00", " ")
    return " ".join(value.split())


class KoreanNgramAnalyzer:
    def __init__(self, min_n: int = 2, max_n: int = 4) -> None:
        self.min_n = min_n
        self.max_n = max_n

    def analyze(self, text: str) -> str:
        normalized = normalize_text(text).lower()
        tokens: list[str] = []
        seen: set[str] = set()
        for match in _TOKEN_RE.finditer(normalized):
            token = match.group(0)
            self._add(tokens, seen, token)
            if _HANGUL_RE.fullmatch(token) and len(token) >= self.min_n:
                upper = min(self.max_n, len(token))
                for size in range(self.min_n, upper + 1):
                    for start in range(0, len(token) - size + 1):
                        self._add(tokens, seen, token[start : start + size])
        return " ".join(tokens)

    @staticmethod
    def _add(tokens: list[str], seen: set[str], value: str) -> None:
        if value and value not in seen:
            seen.add(value)
            tokens.append(value)
