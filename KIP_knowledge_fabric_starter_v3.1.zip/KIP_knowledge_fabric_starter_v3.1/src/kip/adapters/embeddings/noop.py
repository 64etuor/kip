class DisabledEmbeddingAdapter:
    name = "disabled"
    dimensions = 0

    def embed(self, texts):
        raise RuntimeError("semantic search is disabled")
