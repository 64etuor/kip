from pathlib import Path

from typer.testing import CliRunner

from kip.cli import app


ROOT = Path(__file__).resolve().parents[1]


def _env() -> dict[str, str]:
    return {
        "KIP_CONFIG": str(ROOT / "config/kip.example.toml"),
        "KIP_DATABASE_URL": "memory://",
        "KIP_PROJECT_ROOT": str(ROOT),
        "KIP_ENV": "test",
    }


def test_cli_exposes_agent_and_application_compatibility_commands():
    runner = CliRunner()
    result = runner.invoke(app, ["--help"], env=_env())
    assert result.exit_code == 0
    for command in ["doctor", "sync", "xlsx-read", "projection", "export", "explain"]:
        assert command in result.stdout


def test_source_neutral_sync_run_supports_dry_run():
    runner = CliRunner()
    result = runner.invoke(
        app,
        ["sync", "run", "--source", "sample", "--dry-run"],
        env=_env(),
    )
    assert result.exit_code == 0, result.stdout
    assert '"ok": true' in result.stdout
    assert '"source": "sample"' in result.stdout


def test_projection_and_export_command_groups_are_stable(tmp_path: Path):
    runner = CliRunner()
    projection = runner.invoke(app, ["projection", "status"], env=_env())
    assert projection.exit_code == 0, projection.stdout
    assert '"lexical"' in projection.stdout

    output = tmp_path / "canonical.jsonl"
    export = runner.invoke(
        app,
        [
            "--config",
            str(ROOT / "config/kip.example.toml"),
            "export",
            "canonical",
            "--output",
            str(output),
        ],
        env={**_env(), "KIP_PROJECT_ROOT": str(ROOT)},
    )
    assert export.exit_code == 0, export.stdout
    assert output.is_file()
