from __future__ import annotations

from dataclasses import dataclass

from kip.adapters.parsers.registry import ParserRegistry
from kip.adapters.repository.memory import MemoryRepository
from kip.adapters.repository.postgres import PostgresRepository
from kip.application.analyzer import KoreanNgramAnalyzer
from kip.application.services import KnowledgeService
from kip.ports.repository import RepositoryPort
from kip.settings import Settings


@dataclass(slots=True)
class Container:
    settings: Settings
    repository: RepositoryPort
    service: KnowledgeService


def build_container(settings: Settings | None = None, repository: RepositoryPort | None = None) -> Container:
    selected = settings or Settings.load()
    if repository is None:
        if selected.is_memory:
            repository = MemoryRepository()
        else:
            repository = PostgresRepository(
                selected.database_url,
                statement_timeout_ms=int(selected.get("database.statement_timeout_ms", 15000)),
            )
    parsers = ParserRegistry.from_settings(selected)
    analyzer = KoreanNgramAnalyzer(
        min_n=int(selected.get("search.korean_ngram_min", 2)),
        max_n=int(selected.get("search.korean_ngram_max", 4)),
    )
    service = KnowledgeService(selected, repository, parsers, analyzer)
    return Container(settings=selected, repository=repository, service=service)
