from __future__ import annotations

from typing import Protocol, Sequence


class EmbeddingPort(Protocol):
    name: str
    dimensions: int

    def embed(self, texts: Sequence[str]) -> list[list[float]]: ...
