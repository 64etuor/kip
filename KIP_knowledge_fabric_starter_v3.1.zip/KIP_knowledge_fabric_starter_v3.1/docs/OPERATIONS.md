# Operations

## Daily

```bash
./scripts/doctor.sh
./scripts/kip status
./scripts/kip jobs list --status failed
```

## Incremental sync

Use source-specific cursors. A source outage must not be interpreted as deletion. Files are considered deleted only after a successful complete scan confirms absence according to the configured grace policy.

## Backup

```bash
./scripts/backup.sh
```

The backup set contains:

- PostgreSQL custom-format dump;
- ontology and configuration snapshot without secrets;
- CAS manifest and optional CAS archive;
- schema/version metadata.

## Restore drill

Run quarterly. Restore to a new database and CAS path, run migrations, verify row counts, rebuild disposable projections, then run golden queries.

## Projection rebuild

Rebuild lexical, vector, and graph projections independently. Never delete approved assertions to rebuild a projection.

## Parser upgrade

1. Run the new parser in shadow mode.
2. Compare quality and golden corpus output.
3. Keep the previous active extraction until the new extraction passes.
4. Activate atomically.
5. Preserve parser name, version, run ID, warnings, and output hash.
