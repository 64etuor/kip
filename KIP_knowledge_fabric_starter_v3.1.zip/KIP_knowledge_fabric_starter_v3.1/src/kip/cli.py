from __future__ import annotations

import json
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import typer

from kip.container import Container, build_container
from kip.domain.models import (
    AssertionCandidate,
    ContextRequest,
    Envelope,
    EnvelopeMeta,
    ErrorInfo,
    GraphNeighborsRequest,
    GraphPathRequest,
    RequestContext,
    SearchRequest,
)
from kip.errors import AuthorizationError, ConflictError, KipError, NotFoundError, ValidationError
from kip.ids import new_id
from kip.settings import Settings

app = typer.Typer(no_args_is_help=True, add_completion=False, help="KIP knowledge fabric CLI")
sync_app = typer.Typer(no_args_is_help=True, help="Synchronize configured sources")
xlsx_app = typer.Typer(no_args_is_help=True, help="Read exact XLSX ranges")
graph_app = typer.Typer(no_args_is_help=True, help="Traverse approved assertions")
review_app = typer.Typer(no_args_is_help=True, help="Review assertion candidates")
jobs_app = typer.Typer(no_args_is_help=True, help="Inspect durable jobs")
api_app = typer.Typer(no_args_is_help=True, help="Run the optional REST adapter")
worker_app = typer.Typer(no_args_is_help=True, help="Run background jobs")
get_app = typer.Typer(no_args_is_help=True, help="Get canonical objects")
projection_app = typer.Typer(no_args_is_help=True, help="Inspect and rebuild disposable projections")
export_app = typer.Typer(no_args_is_help=True, help="Export portable canonical bundles")

app.add_typer(sync_app, name="sync")
app.add_typer(xlsx_app, name="xlsx")
app.add_typer(graph_app, name="graph")
app.add_typer(review_app, name="review")
app.add_typer(jobs_app, name="jobs")
app.add_typer(api_app, name="api")
app.add_typer(worker_app, name="worker")
app.add_typer(get_app, name="get")
app.add_typer(projection_app, name="projection")
app.add_typer(export_app, name="export")


class Runtime:
    def __init__(self, container: Container, context: RequestContext) -> None:
        self.container = container
        self.context = context


@app.callback()
def root(
    ctx: typer.Context,
    config: Path | None = typer.Option(None, "--config", envvar="KIP_CONFIG", help="TOML configuration path"),
    workspace: str | None = typer.Option(None, "--workspace", envvar="KIP_WORKSPACE"),
    principal: str = typer.Option("principal_local", "--principal", envvar="KIP_PRINCIPAL_ID"),
    acl_scope: list[str] | None = typer.Option(None, "--acl-scope", help="Repeatable access scope"),
    acl_scopes: str | None = typer.Option(
        None,
        "--acl-scopes",
        envvar="KIP_ACL_SCOPES",
        help="Comma-separated access scopes",
    ),
) -> None:
    settings = Settings.load(config)
    container = build_container(settings)
    selected_scopes = list(acl_scope or [])
    if acl_scopes:
        selected_scopes.extend(item.strip() for item in acl_scopes.split(",") if item.strip())
    request_context = container.service.request_context(
        workspace=workspace,
        principal_id=principal,
        acl_scopes=list(dict.fromkeys(selected_scopes)) or None,
    )
    ctx.obj = Runtime(container, request_context)


def _runtime(ctx: typer.Context) -> Runtime:
    value = ctx.find_root().obj
    if not isinstance(value, Runtime):
        raise RuntimeError("CLI runtime is unavailable")
    return value


def _emit(runtime: Runtime, data: Any) -> None:
    envelope = Envelope(
        ok=True,
        data=data.model_dump(mode="json") if hasattr(data, "model_dump") else data,
        meta=EnvelopeMeta(
            request_id=runtime.context.request_id or new_id("req"),
            workspace=runtime.context.workspace,
        ),
    )
    typer.echo(envelope.model_dump_json(indent=2))


def _emit_error(runtime: Runtime | None, exc: Exception) -> None:
    context = runtime.context if runtime else RequestContext(request_id=new_id("req"))
    code = {
        NotFoundError: "not_found",
        ConflictError: "conflict",
        ValidationError: "validation_error",
        AuthorizationError: "forbidden",
    }.get(type(exc), "internal_error")
    envelope = Envelope(
        ok=False,
        error=ErrorInfo(code=code, message=str(exc)),
        meta=EnvelopeMeta(
            request_id=context.request_id or new_id("req"),
            workspace=context.workspace,
        ),
    )
    typer.echo(envelope.model_dump_json(indent=2), err=True)


def _run(ctx: typer.Context, function) -> None:
    runtime: Runtime | None = None
    try:
        runtime = _runtime(ctx)
        _emit(runtime, function(runtime))
    except KipError as exc:
        _emit_error(runtime, exc)
        raise typer.Exit(code=4 if isinstance(exc, NotFoundError) else 3) from exc
    except KeyboardInterrupt as exc:
        if runtime:
            _emit_error(runtime, exc)
        raise typer.Exit(code=130) from exc
    except Exception as exc:
        _emit_error(runtime, exc)
        raise typer.Exit(code=1) from exc


def _split_values(values: list[str] | None) -> list[str]:
    result: list[str] = []
    for value in values or []:
        result.extend(item.strip() for item in value.split(",") if item.strip())
    return list(dict.fromkeys(result))


def _enabled_filesystem_sources(runtime: Runtime) -> list[str]:
    names: list[str] = []
    for source in runtime.container.settings.get("sources.filesystem", []) or []:
        if isinstance(source, dict) and source.get("enabled", True) and source.get("name"):
            names.append(str(source["name"]))
    return names


def _resolve_sync_source(runtime: Runtime, source: str) -> str:
    normalized = source.strip().lower()
    filesystem_sources = _enabled_filesystem_sources(runtime)
    if source in filesystem_sources:
        return source
    if normalized in {"nas", "filesystem", "files"}:
        if len(filesystem_sources) == 1:
            return filesystem_sources[0]
        if not filesystem_sources:
            raise ValidationError("no enabled filesystem source is configured")
        raise ValidationError(
            "multiple filesystem sources are configured; use one of: "
            + ", ".join(filesystem_sources)
        )
    if normalized == "mail":
        candidates = [
            name
            for name, enabled in [
                ("apple-mail", runtime.container.settings.get("sources.apple_mail.enabled", False)),
                ("imap", runtime.container.settings.get("sources.imap.enabled", False)),
            ]
            if enabled
        ]
        if len(candidates) == 1:
            return candidates[0]
        if not candidates:
            raise ValidationError("neither Apple Mail nor IMAP is enabled")
        raise ValidationError("both Apple Mail and IMAP are enabled; choose apple-mail or imap")
    if normalized in {"slack", "apple-mail", "imap", "all"}:
        return normalized
    raise ValidationError(f"unknown source: {source}")


def _sync_one(
    runtime: Runtime,
    source: str,
    *,
    enqueue: bool = False,
    dry_run: bool = False,
    since: str | None = None,
) -> Any:
    selected = _resolve_sync_source(runtime, source)
    if selected == "all":
        results: list[Any] = []
        for name in _enabled_filesystem_sources(runtime):
            results.append(_sync_one(runtime, name, enqueue=enqueue, dry_run=dry_run, since=since))
        for name, enabled in [
            ("slack", runtime.container.settings.get("sources.slack.enabled", False)),
            ("apple-mail", runtime.container.settings.get("sources.apple_mail.enabled", False)),
            ("imap", runtime.container.settings.get("sources.imap.enabled", False)),
        ]:
            if enabled:
                results.append(_sync_one(runtime, name, enqueue=enqueue, dry_run=dry_run, since=since))
        return results
    if enqueue:
        if dry_run:
            raise ValidationError("--enqueue and --dry-run cannot be combined")
        return {"source": selected, "job_id": runtime.container.service.enqueue_sync(runtime.context, selected)}
    if selected in _enabled_filesystem_sources(runtime):
        return runtime.container.service.sync_filesystem(runtime.context, selected, dry_run=dry_run)
    if dry_run:
        raise ValidationError("--dry-run is currently supported only for filesystem sources")
    if selected == "slack":
        return runtime.container.service.sync_slack(runtime.context, oldest=since)
    if selected == "apple-mail":
        return runtime.container.service.sync_apple_mail(runtime.context)
    if selected == "imap":
        return runtime.container.service.sync_imap(runtime.context)
    raise ValidationError(f"unsupported source: {selected}")


@app.command()
def capabilities(ctx: typer.Context) -> None:
    """Report available parsers, connectors, projections, and edge adapters."""
    _run(ctx, lambda runtime: runtime.container.service.capabilities())


@app.command()
def status(ctx: typer.Context) -> None:
    """Report canonical and projection counts."""
    _run(ctx, lambda runtime: runtime.container.repository.status(runtime.context))


@app.command()
def doctor(ctx: typer.Context) -> None:
    """Check configuration, source mounts, storage, and adapter availability."""

    def action(runtime: Runtime):
        settings = runtime.container.settings
        checks: list[dict[str, Any]] = []
        checks.append(
            {
                "name": "configuration",
                "ok": settings.config_path.exists(),
                "required": settings.environment not in {"development", "test"},
                "details": {"path": str(settings.config_path)},
            }
        )
        checks.append(
            {
                "name": "canonical_repository",
                "ok": runtime.container.repository.name in {"postgresql", "memory"},
                "required": True,
                "details": {"backend": runtime.container.repository.name},
            }
        )
        checks.append(
            {
                "name": "content_addressed_store",
                "ok": settings.cas_path.exists() and settings.cas_path.is_dir(),
                "required": True,
                "details": {"path": str(settings.cas_path)},
            }
        )
        for source in settings.get("sources.filesystem", []) or []:
            if not isinstance(source, dict) or not source.get("enabled", True):
                continue
            root_value = source.get("root")
            root_path = Path(str(root_value)).expanduser().resolve() if root_value else None
            checks.append(
                {
                    "name": f"filesystem_source:{source.get('name', 'unnamed')}",
                    "ok": bool(root_path and root_path.exists() and root_path.is_dir()),
                    "required": True,
                    "details": {
                        "path": str(root_path) if root_path else None,
                        "configured_read_only": bool(source.get("read_only", False)),
                    },
                }
            )
        capabilities = runtime.container.service.capabilities()
        required_failures = [item["name"] for item in checks if item["required"] and not item["ok"]]
        return {
            "healthy": not required_failures,
            "required_failures": required_failures,
            "checks": checks,
            "capabilities": capabilities.model_dump(mode="json"),
        }

    _run(ctx, action)


@app.command()
def migrate(ctx: typer.Context) -> None:
    """Apply append-only PostgreSQL migrations."""
    _run(ctx, lambda runtime: {"applied": runtime.container.service.migrate()})


@app.command()
def search(
    ctx: typer.Context,
    query: str | None = typer.Argument(None),
    query_option: str | None = typer.Option(None, "--query"),
    limit: int = typer.Option(10, min=1, max=100),
    source_kind: list[str] | None = typer.Option(None, "--source-kind"),
    document_type: list[str] | None = typer.Option(None, "--document-type"),
    project_id: list[str] | None = typer.Option(None, "--project-id"),
) -> None:
    """Search exact identifiers and lexical evidence units."""
    def action(runtime: Runtime):
        selected_query = query_option or query
        if not selected_query:
            raise ValidationError("provide QUERY or --query")
        request = SearchRequest(
            query=selected_query,
            limit=limit,
            source_kinds=_split_values(source_kind),
            document_types=_split_values(document_type),
            project_ids=_split_values(project_id),
        )
        return runtime.container.service.search(runtime.context, request)
    _run(ctx, action)


@app.command()
def vocab(
    ctx: typer.Context,
    prefix: str | None = typer.Argument(None),
    term: str | None = typer.Option(None, "--term"),
    limit: int = typer.Option(20, min=1, max=100),
) -> None:
    """Inspect terms that actually exist in the lexical projection."""
    def action(runtime: Runtime):
        selected = term or prefix
        if not selected:
            raise ValidationError("provide PREFIX or --term")
        return runtime.container.service.vocabulary(runtime.context, selected, limit)

    _run(ctx, action)


@app.command(name="context")
def context_command(
    ctx: typer.Context,
    query: str | None = typer.Argument(None),
    query_option: str | None = typer.Option(None, "--query"),
    limit: int = typer.Option(5, min=1, max=30),
    max_chars: int = typer.Option(40000, min=1000, max=200000),
    source_kind: list[str] | None = typer.Option(None, "--source-kind"),
) -> None:
    """Build a bounded evidence bundle for an AI agent or application."""
    def action(runtime: Runtime):
        selected_query = query_option or query
        if not selected_query:
            raise ValidationError("provide QUERY or --query")
        request = ContextRequest(
            query=selected_query,
            limit=limit,
            max_chars=max_chars,
            source_kinds=_split_values(source_kind),
        )
        return runtime.container.service.context_bundle(runtime.context, request)
    _run(ctx, action)


@app.command()
def read(
    ctx: typer.Context,
    unit_id: str | None = typer.Argument(None),
    unit_id_option: str | None = typer.Option(None, "--unit-id"),
) -> None:
    """Read one exact evidence unit and report source staleness."""
    selected = unit_id_option or unit_id
    if not selected:
        raise typer.BadParameter("provide UNIT_ID or --unit-id")
    _run(ctx, lambda runtime: runtime.container.service.read_unit(runtime.context, selected))


@get_app.command("artifact")
def get_artifact(ctx: typer.Context, artifact_id: str = typer.Argument(...)) -> None:
    _run(ctx, lambda runtime: runtime.container.repository.get_artifact(runtime.context, artifact_id))


@get_app.command("document")
def get_document(ctx: typer.Context, document_id: str = typer.Argument(...)) -> None:
    _run(ctx, lambda runtime: runtime.container.repository.get_document(runtime.context, document_id))


@get_app.command("candidate")
def get_candidate(ctx: typer.Context, candidate_id: str = typer.Argument(...)) -> None:
    _run(ctx, lambda runtime: runtime.container.repository.get_candidate(runtime.context, candidate_id))


@get_app.command("assertion")
def get_assertion(ctx: typer.Context, assertion_id: str = typer.Argument(...)) -> None:
    _run(ctx, lambda runtime: runtime.container.repository.get_assertion(runtime.context, assertion_id))


@app.command()
def explain(ctx: typer.Context, assertion_id: str = typer.Option(..., "--assertion-id")) -> None:
    """Explain an approved assertion with its exact evidence units."""
    _run(ctx, lambda runtime: runtime.container.service.explain_assertion(runtime.context, assertion_id))


@sync_app.command("all")
def sync_all(
    ctx: typer.Context,
    enqueue: bool = typer.Option(False, "--enqueue"),
    dry_run: bool = typer.Option(False, "--dry-run"),
) -> None:
    _run(ctx, lambda runtime: _sync_one(runtime, "all", enqueue=enqueue, dry_run=dry_run))


@sync_app.command("run")
def sync_run(
    ctx: typer.Context,
    source: str = typer.Option(..., "--source", help="Configured source name, nas, slack, mail, or all"),
    mode: str = typer.Option("incremental", "--mode", help="Starter supports incremental mode"),
    since: str | None = typer.Option(None, "--since", help="Optional Slack oldest timestamp"),
    enqueue: bool = typer.Option(False, "--enqueue"),
    dry_run: bool = typer.Option(False, "--dry-run"),
) -> None:
    """Compatibility entry point for source-neutral synchronization."""

    def action(runtime: Runtime):
        if mode != "incremental":
            raise ValidationError(
                "the starter kit implements safe incremental sync only; "
                "source reconciliation and forced full re-extraction require an explicit operator workflow"
            )
        return _sync_one(runtime, source, enqueue=enqueue, dry_run=dry_run, since=since)

    _run(ctx, action)


@sync_app.command("filesystem")
def sync_filesystem(
    ctx: typer.Context,
    source: str = typer.Option(..., "--source"),
    dry_run: bool = typer.Option(False, "--dry-run"),
    enqueue: bool = typer.Option(False, "--enqueue", help="Create a durable worker job instead of running now"),
) -> None:
    _run(ctx, lambda runtime: _sync_one(runtime, source, enqueue=enqueue, dry_run=dry_run))


@sync_app.command("slack")
def sync_slack(ctx: typer.Context, oldest: str | None = typer.Option(None)) -> None:
    _run(ctx, lambda runtime: _sync_one(runtime, "slack", since=oldest))


@sync_app.command("imap")
def sync_imap(ctx: typer.Context) -> None:
    _run(ctx, lambda runtime: _sync_one(runtime, "imap"))


@sync_app.command("apple-mail")
def sync_apple_mail(ctx: typer.Context) -> None:
    _run(ctx, lambda runtime: _sync_one(runtime, "apple-mail"))


@xlsx_app.command("read")
def xlsx_read(
    ctx: typer.Context,
    artifact_id: str = typer.Argument(...),
    sheet: str = typer.Option(..., "--sheet"),
    cell_range: str = typer.Option(..., "--range"),
    allow_stale: bool = typer.Option(False, "--allow-stale"),
) -> None:
    _run(
        ctx,
        lambda runtime: runtime.container.service.read_xlsx(
            runtime.context,
            artifact_id,
            sheet=sheet,
            cell_range=cell_range,
            require_fresh=not allow_stale,
        ),
    )


@app.command(name="xlsx-read")
def xlsx_read_alias(
    ctx: typer.Context,
    artifact_id: str | None = typer.Argument(None),
    artifact_id_option: str | None = typer.Option(None, "--artifact-id"),
    sheet: str = typer.Option(..., "--sheet"),
    cell_range: str = typer.Option(..., "--range"),
    require_fresh: bool = typer.Option(True, "--require-fresh/--allow-stale"),
) -> None:
    """Read an exact XLSX range; stable top-level alias for agents and apps."""
    selected_artifact = artifact_id_option or artifact_id
    if not selected_artifact:
        raise typer.BadParameter("provide ARTIFACT_ID or --artifact-id")
    _run(
        ctx,
        lambda runtime: runtime.container.service.read_xlsx(
            runtime.context,
            selected_artifact,
            sheet=sheet,
            cell_range=cell_range,
            require_fresh=require_fresh,
        ),
    )


@graph_app.command("neighbors")
def graph_neighbors(
    ctx: typer.Context,
    node_id: str = typer.Option(..., "--node-id"),
    predicate: list[str] | None = typer.Option(None, "--predicate"),
    direction: str = typer.Option("both"),
    limit: int = typer.Option(100, min=1, max=1000),
) -> None:
    _run(
        ctx,
        lambda runtime: runtime.container.repository.graph_neighbors(
            runtime.context,
            GraphNeighborsRequest(
                node_id=node_id,
                predicates=_split_values(predicate),
                direction=direction,  # type: ignore[arg-type]
                limit=limit,
            ),
        ),
    )


@graph_app.command("path")
def graph_path(
    ctx: typer.Context,
    from_node: str = typer.Option(..., "--from"),
    to_node: str = typer.Option(..., "--to"),
    predicate: list[str] | None = typer.Option(None, "--predicate"),
    max_depth: int = typer.Option(4, min=1, max=8),
) -> None:
    _run(
        ctx,
        lambda runtime: runtime.container.repository.graph_path(
            runtime.context,
            GraphPathRequest(
                from_node_id=from_node,
                to_node_id=to_node,
                predicates=_split_values(predicate),
                max_depth=max_depth,
            ),
        ),
    )


@review_app.command("list")
def review_list(
    ctx: typer.Context,
    status_value: str = typer.Option("proposed", "--status"),
    limit: int = typer.Option(100, min=1, max=1000),
) -> None:
    _run(ctx, lambda runtime: runtime.container.repository.list_candidates(runtime.context, status_value, limit))


@review_app.command("propose")
def review_propose(
    ctx: typer.Context,
    subject_id: str = typer.Option(...),
    predicate: str = typer.Option(...),
    object_entity_id: str | None = typer.Option(None),
    object_json: str | None = typer.Option(None, help="JSON literal for a value object"),
    evidence_unit_id: list[str] | None = typer.Option(None),
    origin: str = typer.Option("human"),
    ontology_version: str = typer.Option("core/1.0.0"),
    confidence: float | None = typer.Option(None),
) -> None:
    def action(runtime: Runtime):
        object_value: Any = None
        if object_json is not None:
            object_value = json.loads(object_json)
        candidate = AssertionCandidate(
            id=new_id("cand"),
            subject_id=subject_id,
            predicate=predicate,
            object_entity_id=object_entity_id,
            object_value=object_value,
            origin=origin,
            confidence=confidence,
            ontology_version=ontology_version,
            evidence=[{"content_unit_id": value} for value in (evidence_unit_id or [])],
        )
        return runtime.container.service.create_candidate(runtime.context, candidate)
    _run(ctx, action)


@review_app.command("approve")
def review_approve(
    ctx: typer.Context,
    candidate_id: str = typer.Argument(...),
    note: str | None = typer.Option(None),
) -> None:
    _run(ctx, lambda runtime: runtime.container.service.review_approve(runtime.context, candidate_id, note))


@review_app.command("reject")
def review_reject(
    ctx: typer.Context,
    candidate_id: str = typer.Argument(...),
    note: str | None = typer.Option(None),
) -> None:
    _run(ctx, lambda runtime: runtime.container.service.review_reject(runtime.context, candidate_id, note))


@jobs_app.command("list")
def jobs_list(
    ctx: typer.Context,
    status_value: str | None = typer.Option(None, "--status"),
    limit: int = typer.Option(100, min=1, max=1000),
) -> None:
    _run(ctx, lambda runtime: runtime.container.repository.list_jobs(runtime.context, status_value, limit))


@projection_app.command("status")
def projection_status(ctx: typer.Context) -> None:
    """Report projection counts and configured optional backends."""

    def action(runtime: Runtime):
        status_report = runtime.container.repository.status(runtime.context)
        return {
            "lexical": {
                "content_units": status_report.content_units,
                "indexed_units": status_report.lexical_units,
                "in_sync": status_report.content_units == status_report.lexical_units,
            },
            "graph": {
                "backend": runtime.container.settings.get("graph.backend", "postgres"),
                "approved_assertions": status_report.approved_assertions,
                "canonical_query": True,
            },
            "semantic": {
                "enabled": bool(runtime.container.settings.get("search.semantic_enabled", False)),
            },
        }

    _run(ctx, action)


@projection_app.command("rebuild")
def projection_rebuild(
    ctx: typer.Context,
    name: str = typer.Option("lexical", "--name"),
    enqueue: bool = typer.Option(False, "--enqueue"),
) -> None:
    """Rebuild a disposable projection without mutating canonical assertions."""

    def action(runtime: Runtime):
        if enqueue:
            job_id = runtime.container.repository.enqueue_job(
                runtime.context,
                "rebuild.projection",
                {"projection": name, "workspace": runtime.context.workspace},
                idempotency_key=f"rebuild:{runtime.context.workspace}:{name}",
            )
            return {"projection": name, "job_id": job_id}
        return runtime.container.repository.rebuild_projection(runtime.context, name)

    _run(ctx, action)


@projection_app.command("verify")
def projection_verify(ctx: typer.Context, name: str = typer.Option("lexical", "--name")) -> None:
    """Run low-cost parity checks for a projection."""

    def action(runtime: Runtime):
        report = runtime.container.repository.status(runtime.context)
        if name == "lexical":
            ok = report.content_units == report.lexical_units
            return {
                "projection": name,
                "ok": ok,
                "content_units": report.content_units,
                "lexical_units": report.lexical_units,
            }
        if name == "graph":
            return {
                "projection": name,
                "ok": True,
                "backend": runtime.container.settings.get("graph.backend", "postgres"),
                "approved_assertions": report.approved_assertions,
                "note": "the baseline queries canonical PostgreSQL assertions directly",
            }
        raise ValidationError(f"unsupported projection verification: {name}")

    _run(ctx, action)


@app.command()
def rebuild(
    ctx: typer.Context,
    projection: str = typer.Option("lexical", "--projection"),
    enqueue: bool = typer.Option(False, "--enqueue"),
) -> None:
    """Backward-compatible alias for `projection rebuild`."""

    def action(runtime: Runtime):
        if enqueue:
            job_id = runtime.container.repository.enqueue_job(
                runtime.context,
                "rebuild.projection",
                {"projection": projection, "workspace": runtime.context.workspace},
                idempotency_key=f"rebuild:{runtime.context.workspace}:{projection}",
            )
            return {"projection": projection, "job_id": job_id}
        return runtime.container.repository.rebuild_projection(runtime.context, projection)

    _run(ctx, action)


@export_app.command("canonical")
def export_canonical(
    ctx: typer.Context,
    output: Path = typer.Option(Path("exports/canonical.jsonl"), "--output"),
) -> None:
    """Export canonical records as deterministic JSONL for migration or backup."""
    _run(ctx, lambda runtime: runtime.container.repository.export_canonical(runtime.context, output))


@app.command(name="export-file", hidden=True)
def export_file_alias(
    ctx: typer.Context,
    output: Path = typer.Option(Path("exports/canonical.jsonl"), "--output"),
) -> None:
    """Legacy alias retained for scripts created before v3.1."""
    _run(ctx, lambda runtime: runtime.container.repository.export_canonical(runtime.context, output))


@api_app.command("serve")
def api_serve(
    ctx: typer.Context,
    host: str | None = typer.Option(None),
    port: int | None = typer.Option(None),
) -> None:
    runtime = _runtime(ctx)
    try:
        import uvicorn
    except ImportError as exc:
        _emit_error(runtime, exc)
        raise typer.Exit(code=2) from exc
    uvicorn.run(
        "kip.api:create_app_from_environment",
        factory=True,
        host=host or runtime.container.settings.api_host,
        port=port or runtime.container.settings.api_port,
        reload=False,
    )


@worker_app.command("run")
def worker_run(
    ctx: typer.Context,
    once: bool = typer.Option(False, "--once"),
    poll_seconds: float = typer.Option(2.0, min=0.1, max=60),
) -> None:
    runtime = _runtime(ctx)
    from kip.worker import run_worker

    run_worker(runtime.container, once=once, poll_seconds=poll_seconds)


def main() -> None:
    app()


if __name__ == "__main__":
    main()
